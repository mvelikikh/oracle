host ls -l &SQLPATH/&1
