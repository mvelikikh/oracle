-- count rows in a table
select count(*) from &1;

