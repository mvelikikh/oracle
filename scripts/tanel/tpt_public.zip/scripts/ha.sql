host " doskey /history /exename=sqlplus.exe | find /v /n "dummy_non_existent_blah_tanel" "
