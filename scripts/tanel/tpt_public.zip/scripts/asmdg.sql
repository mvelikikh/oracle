select * from v$asm_diskgroup;

