@grp "power(&3,trunc(log(&3,&1)))" "&2"
