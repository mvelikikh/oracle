SELECT CHR('&1') FROM dual;
