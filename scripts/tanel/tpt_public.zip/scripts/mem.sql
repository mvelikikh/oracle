prompt Show instance memory usage breakdown from v$memory_dynamic_components
select * from v$memory_dynamic_components;
